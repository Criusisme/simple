Tessellate by HTML5 UP
html5up.net | @ajlkn
Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)


This is Tessellate, a brand new responsive site template by AJ for HTML5 UP. It's a
single pager (a format I'm pretty into right now), has styling for a crapload of
basic elements, and includes a handy "dark" modifier class to flip a given element
to a light-on-dark color scheme.

Demo images* courtesy of Felicia Simion, a highly creative photographer/artist
friend of mine over at deviantART. See more of her incredible work here:

http://ineedchemicalx.deviantart.com/

(* = Not included! Only meant for use with my own on-site demo, so please do NOT download
and/or use any of Felicia's work without her explicit permission!)

AJ
aj@lkn.io | @ajlkn

PS: Not sure how to get that contact form working? Give formspree.io a try (it's awesome).


Credits:

	Demo Images:
		Felicia Simion (ineedchemicalx.deviantart.com)
			"Look for the bare necessities of life" (ineedchemicalx.deviantart.com/art/Look-for-the-bare-necessities-of-life-402262777)
			"You and I collide" (ineedchemicalx.deviantart.com/art/You-and-I-collide-401457901)
			"Emperor of the Stars" (ineedchemicalx.deviantart.com/art/Emperor-of-the-Stars-370265193)
			"Sherlockin" (ineedchemicalx.deviantart.com/art/Sherlockin-369847236)
			"A breath of Hope" (ineedchemicalx.deviantart.com/art/A-breath-of-Hope-366359145)
			"The Pursuit" (ineedchemicalx.deviantart.com/art/The-Pursuit-355003425)
			"Cherish" (ineedchemicalx.deviantart.com/art/Cherish-320041163)
			"Mind is a clear stage" (ineedchemicalx.deviantart.com/art/Mind-is-a-clear-stage-375431607)

	Icons:
		Font Awesome (fontawesome.io)

	Other:
		jQuery (jquery.com)
		Responsive Tools (github.com/ajlkn/responsive-tools)